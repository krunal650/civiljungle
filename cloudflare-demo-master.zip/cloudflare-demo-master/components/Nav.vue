<template>
  <div class="mt-4 text-xl">
    <ul class="flex justify-end">
      <li class="mr-6">
        <a class="text-black-500 hover:text-orange-500" href="https://youtu.be/Fkm3e0j2sbU">Tutorial</a>
      </li>
      <li class="mr-6">
        <a
          class="text-black-500 hover:text-orange-500"
          href="https://github.com/lauragift21/cloudflare-demo"
        >
          GitHub
        </a>
      </li>
    </ul>
  </div>
</template>
